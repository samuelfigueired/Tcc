# Importando os módulos necessários do Flask
from flask import Flask, render_template, request, redirect, url_for, send_from_directory, flash, jsonify,session
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import os
import logging
from flask_migrate import Migrate
from flask_mail import Mail, Message

# Inicializando o aplicativo Flask
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///tcc.db"
app.config['SECRET_KEY'] = 'segredo'

# Configurações do Flask-Mail
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'gabrieloliveirapc3@gmail.com'
app.config['MAIL_PASSWORD'] = 'cfwgbjmzxtpxxgzw'

mail = Mail(app)

logging.basicConfig(level=logging.DEBUG)

# Inicializando o objeto SQLAlchemy com o aplicativo Flask
db = SQLAlchemy(app)
login_manager = LoginManager(app)
migrate = Migrate(app, db)

class Usuario(db.Model, UserMixin):
    __tablename__ = 'usuarios'
    id = db.Column(db.Integer, autoincrement=True, primary_key=True)
    nome = db.Column(db.String(86), nullable=False)
    email = db.Column(db.String(84), nullable=False, unique=True)
    senha = db.Column(db.String(255), nullable=False)

    def __init__(self, nome, email, senha):
        self.nome = nome
        self.email = email
        self.senha = generate_password_hash(senha)

    def verificar_senha(self, senha_digitada):
        return check_password_hash(self.senha, senha_digitada)

@login_manager.user_loader
def carregar_usuario(user_id):
    return Usuario.query.get(int(user_id))

class Filme(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    titulo = db.Column(db.String(100), nullable=False)
    descricao = db.Column(db.Text)
    preco = db.Column(db.Float)
    capa = db.Column(db.String(255))
    estoque = db.Column(db.Integer, default=0)

class Carrinho(db.Model):
    __tablename__ = 'carrinho'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('usuarios.id'), nullable=False)
    filme_id = db.Column(db.Integer, db.ForeignKey('filme.id'), nullable=False)
    local = db.Column(db.String(100), nullable=False)
    data = db.Column(db.String(10), nullable=False)
    horario = db.Column(db.String(5), nullable=False)
    sala = db.Column(db.String(10), nullable=False)
    poltrona = db.Column(db.String(10), nullable=False)
    lanche = db.Column(db.String(50), nullable=False)
    preco_total = db.Column(db.Float, nullable=False)

    usuario = db.relationship('Usuario', backref=db.backref('carrinho', lazy=True))
    filme = db.relationship('Filme', backref=db.backref('carrinho', lazy=True))

class Sala(db.Model):
    __tablename__ = 'salas'
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(255), nullable=False)

class Poltrona(db.Model):
    __tablename__ = 'poltronas'
    id = db.Column(db.Integer, primary_key=True)
    sala_id = db.Column(db.Integer, db.ForeignKey('salas.id'), nullable=False)
    poltrona_numero = db.Column(db.String(10), nullable=False)
    estado = db.Column(db.Enum('disponivel', 'ocupado'), default='disponivel', nullable=False)

class Compra(db.Model):
    __tablename__ = 'compras'
    id = db.Column(db.Integer, primary_key=True)
    usuario_id = db.Column(db.Integer, db.ForeignKey('usuarios.id'), nullable=False)
    filme_id = db.Column(db.Integer, db.ForeignKey('filme.id'), nullable=False)
    local = db.Column(db.String(100))
    data = db.Column(db.String(20))
    horario = db.Column(db.String(10))
    sala = db.Column(db.String(10))
    poltrona = db.Column(db.String(10))
    lanche = db.Column(db.String(100))

def enviar_email_confirmacao(mail, destinatario, carrinho_items):
    try:
        assunto = "Confirmação de Pedido"
        corpo = f"""
        Olá,

        Seu pedido foi confirmado com sucesso!

        Detalhes do pedido:
        {''.join([f'Filme: {item.filme_id}, Local: {item.local}, Data: {item.data}, Horário: {item.horario}, Sala: {item.sala}, Poltrona: {item.poltrona}, Lanche: {item.lanche}\n' for item in carrinho_items])}

        Obrigado por escolher nosso cinema!

        Atenciosamente,
        Sua Equipe de Cinema
        """

        msg = Message(subject=assunto, body=corpo, recipients=[destinatario])
        mail.send(msg)
    except Exception as e:
        app.logger.error(f"Erro ao enviar email: {e}")

@app.route('/')
def inicio():
    filmes = Filme.query.all()
    return render_template('home.html', filmes=filmes)

@app.route('/registro', methods=['GET', 'POST'])
def registro():
    if request.method == 'POST':
        nome = request.form['name']
        email = request.form['email']
        senha = request.form['password']

        usuario = Usuario(nome, email, senha)
        db.session.add(usuario)
        db.session.commit()

        return redirect(url_for('login'))

    return render_template('registro.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        senha = request.form['password']

        usuario = Usuario.query.filter_by(email=email).first()

        if not usuario or not usuario.verificar_senha(senha):
            flash('Email ou senha incorretos', 'danger')
            return redirect(url_for('login'))

        login_user(usuario)
        return redirect(url_for('inicio'))

    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

app.config['UPLOAD_FOLDER'] = 'static/capas_filmes'

@app.route('/static/capas_filmes/<path:filename>')
def servir_capa(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/adicionar_ao_carrinho/<int:filme_id>', methods=['POST'])
@login_required
def adicionar_ao_carrinho(filme_id):
    try:
        filme = Filme.query.get(filme_id)
        if filme is None:
            return jsonify(success=False, message='Filme não encontrado'), 404

        local = session.get('local', 'Local Padrão')
        data = session.get('data', 'Data Padrão')
        horario = session.get('horario', 'Horário Padrão')
        sala = session.get('sala', 'Sala Padrão')
        poltrona = session.get('poltrona', 'Poltrona Padrão')
        lanche = session.get('lanche', 'Lanche Padrão')
        
        preco_total = filme.preco

        novo_item = Carrinho(
            user_id=current_user.id,
            filme_id=filme_id,
            local=local,
            data=data,
            horario=horario,
            sala=sala,
            poltrona=poltrona,
            lanche=lanche,
            preco_total=preco_total
        )
        db.session.add(novo_item)
        db.session.commit()

        return jsonify(success=True), 200

    except Exception as e:
        app.logger.error(f"Erro ao adicionar ao carrinho: {e}")
        return jsonify(success=False, message='Erro ao adicionar filme ao carrinho: ' + str(e)), 500

@app.route('/carrinho')
@login_required
def carrinho():
    try:
        carrinho_items = Carrinho.query.filter_by(user_id=current_user.id).all()
        detalhes_filmes = {}
        total = 0

        for item in carrinho_items:
            filme = Filme.query.get(item.filme_id)
            if filme:
                detalhes_filmes[item.filme_id] = filme
                total += filme.preco

        return render_template('carrinho.html', carrinho_items=carrinho_items, detalhes_filmes=detalhes_filmes, total=total)
    except Exception as e:
        app.logger.error(f"Erro ao carregar o carrinho: {e}")
        return jsonify(success=False, message='Erro ao carregar o carrinho.'), 500

@app.route('/remover_do_carrinho/<int:filme_id>', methods=['POST'])
@login_required
def remover_do_carrinho(filme_id):
    try:
        carrinho_item = Carrinho.query.filter_by(user_id=current_user.id, filme_id=filme_id).first()
        if carrinho_item:
            db.session.delete(carrinho_item)
            db.session.commit()
            return jsonify(success=True, message='Filme removido do carrinho'), 200
        else:
            return jsonify(success=False, message='Filme não encontrado no carrinho'), 404
    except Exception as e:
        app.logger.error(f"Erro ao remover do carrinho: {e}")
        return jsonify(success=False, message='Erro ao remover filme do carrinho: ' + str(e)), 500

@app.route('/carrinho_total')
@login_required
def carrinho_total():
    try:
        carrinho_items = Carrinho.query.filter_by(user_id=current_user.id).all()
        total = sum(item.preco_total for item in carrinho_items)
        return jsonify(total=total)
    except Exception as e:
        app.logger.error(f"Erro ao calcular o total do carrinho: {e}")
        return jsonify(success=False, message='Erro ao calcular o total do carrinho.'), 500

@app.route('/poltronas/<int:sala_id>')
def get_poltronas(sala_id):
    try:
        poltronas = Poltrona.query.filter_by(sala_id=sala_id).all()
        poltronas_disponiveis = [{'id': p.id, 'numero': p.poltrona_numero} for p in poltronas if p.estado == 'disponivel']
        return jsonify(poltronas=poltronas_disponiveis)
    except Exception as e:
        app.logger.error(f"Erro ao obter poltronas: {e}")
        return jsonify(success=False, message=str(e)), 500

@app.route('/revisao_pedido', methods=['GET', 'POST'])
@login_required
def revisao_pedido():
    return render_template('revisao_pedido.html')

@app.route('/atualizar_carrinho/<int:filme_id>', methods=['POST'])
@login_required
def atualizar_carrinho(filme_id):
    try:
        dados = request.get_json()
        app.logger.debug(f"Dados de atualização recebidos: {dados}")

        local = dados.get('local')
        data = dados.get('data')
        horario = dados.get('horario')
        sala = dados.get('sala')
        poltrona = dados.get('poltrona')
        lanche = dados.get('lanche')

        carrinho_item = Carrinho.query.filter_by(user_id=current_user.id, filme_id=filme_id).first()

        if carrinho_item:
            if local:
                carrinho_item.local = local
            if data:
                carrinho_item.data = data
            if horario:
                carrinho_item.horario = horario
            if sala:
                carrinho_item.sala = sala
            if poltrona:
                carrinho_item.poltrona = poltrona
            if lanche:
                carrinho_item.lanche = lanche

            db.session.commit()
            return jsonify(success=True), 200
        else:
            return jsonify(success=False, message='Item não encontrado no carrinho'), 404

    except Exception as e:
        app.logger.error(f"Erro ao atualizar o carrinho: {e}")
        return jsonify(success=False, message='Erro ao atualizar o carrinho: ' + str(e)), 500


@app.route('/confirmacao_pedido', methods=['POST'])
@login_required
def confirmacao_pedido():
    try:
        usuario = current_user
        email = usuario.email

        local = request.form.get('local')
        data = request.form.get('data')
        horario = request.form.get('horario')
        sala = request.form.get('sala')
        poltrona = request.form.get('poltrona')
        lanche = request.form.get('lanche')

        # Verifica se o campo 'lanche' está corretamente preenchido
        if not lanche or lanche == 'undefined':
            app.logger.error("Campo 'lanche' está faltando ou indefinido.")
            lanche = 'Nenhum lanche selecionado'

        carrinho_items = Carrinho.query.filter_by(user_id=usuario.id).all()
        filme_ids = [item.filme_id for item in carrinho_items]

        app.logger.info(f"Dados recebidos: local={local}, data={data}, horario={horario}, sala={sala}, poltrona={poltrona}, lanche={lanche}, filmes={filme_ids}")
        app.logger.info(f"Request form data: {request.form}")

        filmes = Filme.query.filter(Filme.id.in_(filme_ids)).all()

        if all([local, data, horario, sala, poltrona, lanche]):
            for item in carrinho_items:
                item.local = local
                item.data = data
                item.horario = horario
                item.sala = sala
                item.poltrona = poltrona
                item.lanche = lanche
            db.session.commit()

        poltrona_ocupada = Poltrona.query.filter_by(sala_id=sala, poltrona_numero=poltrona).first()
        if poltrona_ocupada:
            poltrona_ocupada.estado = 'ocupado'
            db.session.commit()

        detalhes_pedidos = ''.join([f'Filme: {filme.titulo}, Local: {local}, Data: {data}, Horário: {horario}, Sala: {sala}, Poltrona: {poltrona}, Lanche: {lanche}\n' for filme in filmes])
        msg = Message('Confirmação de Pedido', sender='gabrieloliveirapc3@gmail.com', recipients=[email])
        msg.body = f'''
        Seu pedido foi confirmado!

        Detalhes do Pedido:
        {detalhes_pedidos}

        Obrigado por comprar conosco!
        '''
        mail.send(msg)

        return render_template('confirmacao_pedido.html', carrinho_items=carrinho_items, detalhes_filmes={filme.id: filme for filme in filmes}, total=sum(filme.preco for filme in filmes))
    except Exception as e:
        app.logger.error(f"Erro na confirmação do pedido: {e}")
        return render_template('error.html', message=str(e)), 500


if __name__ == '__main__':
    app.run(debug=True)
