console.log('Carrinho.js carregado');

let pedido = {
    local: '',
    data: '',
    horario: '',
    sala: '',
    poltrona: '',
    lanche: ''
};

document.addEventListener('DOMContentLoaded', function() {
    // Adiciona evento de clique para os botões "Adicionar ao Carrinho"
    document.querySelectorAll('.adicionar-carrinho').forEach(button => {
        button.addEventListener('click', function(event) {
            event.preventDefault();
            const filmeId = this.getAttribute('data-filme-id');
            adicionarFilmeAoCarrinho(filmeId);
        });
    });

    // Adiciona evento de clique para os botões "Remover do Carrinho"
    document.querySelectorAll('.remover-carrinho').forEach(button => {
        button.addEventListener('click', function(event) {
            event.preventDefault();
            const filmeId = this.getAttribute('data-filme-id');
            removerFilmeDoCarrinho(filmeId);
        });
    });
});

// Função para enviar uma solicitação POST para adicionar o filme ao carrinho
function adicionarFilmeAoCarrinho(filmeId) {
    const dadosAdicionais = {
        local: pedido.local,
        data: pedido.data,
        horario: pedido.horario,
        sala: pedido.sala,
        poltrona: pedido.poltrona,
        lanche: pedido.lanche
    };

    fetch(`/adicionar_ao_carrinho/${filmeId}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(dadosAdicionais)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Filme adicionado ao carrinho com sucesso!');
            atualizarTotal();
        } else {
            alert('Erro ao adicionar filme ao carrinho: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Erro:', error);
    });
}

// Função para enviar uma solicitação POST para remover o filme do carrinho
function removerFilmeDoCarrinho(filmeId) {
    fetch(`/remover_do_carrinho/${filmeId}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ filme_id: filmeId })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Filme removido do carrinho');
            location.reload(); // Recarrega a página após remover o filme
        } else {
            console.log(data.message); // Para depuração
            alert('Erro ao remover filme do carrinho: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Erro:', error);
    });
}

// Função para atualizar o valor total
function atualizarTotal() {
    let total = 0;
    const filmesCalculados = {}; // Objeto para rastrear os IDs dos filmes já calculados
    document.querySelectorAll('.card').forEach(card => {
        const filmeId = card.querySelector('.remover-carrinho') ? card.querySelector('.remover-carrinho').getAttribute('data-filme-id') : null;
        if (filmeId && !filmesCalculados[filmeId]) { // Verifica se o filme já foi calculado
            const preco = parseFloat(card.querySelector('.card-text').innerText.replace('Preço: R$ ', ''));
            const quantidade = parseInt(card.querySelector('.card-text + .card-text').innerText.replace('Quantidade: ', '')) || 1;
            total += preco * quantidade;
            filmesCalculados[filmeId] = true; // Registra o ID do filme como calculado
        }
    });
    document.getElementById('total').innerText = `Total: R$ ${total.toFixed(2)}`;
}
