document.addEventListener('DOMContentLoaded', () => {
    const images = document.querySelectorAll('.floating-image');

    images.forEach(image => {
        moveImage(image);
    });

    function moveImage(image) {
        const xMax = window.innerWidth * 0.5 - image.width; // Maximum x value (50% of the window width minus image width)
        const yMax = window.innerHeight - image.height; // Maximum y value (window height minus image height)
        let xPos = Math.random() * xMax;
        let yPos = Math.random() * yMax;
        let xSpeed = (Math.random() * 2 + 1) * (Math.random() < 0.5 ? 1 : -1);
        let ySpeed = (Math.random() * 2 + 1) * (Math.random() < 0.5 ? 1 : -1);

        function animate() {
            xPos += xSpeed;
            yPos += ySpeed;

            if (xPos <= 0 || xPos >= xMax) xSpeed *= -1;
            if (yPos <= 0 || yPos >= yMax) ySpeed *= -1;

            image.style.transform = `translate(${xPos}px, ${yPos}px)`;
            requestAnimationFrame(animate);
        }

        animate();
    }
});
