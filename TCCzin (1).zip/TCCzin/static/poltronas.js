document.addEventListener("DOMContentLoaded", function() {
    carregarPoltronas(); // Chama carregarPoltronas ao carregar a página
});

function carregarPoltronas() {
    const salaId = document.getElementById('sala').value;
    fetch(`/poltronas/${salaId}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro ao carregar poltronas');
            }
            return response.json();
        })
        .then(poltronas => {
            const container = document.getElementById('poltronas-container');
            container.innerHTML = ''; // Limpa o conteúdo anterior
            for (const [numero, estado] of Object.entries(poltronas)) {
                const div = document.createElement('div');
                div.className = `poltrona ${estado}`;
                div.innerText = numero;
                div.onclick = () => selecionarPoltrona(div, numero);
                container.appendChild(div); // Adiciona a div de poltrona ao container
            }
        })
        .catch(error => {
            console.error('Erro:', error);
            // Adicione um tratamento de erro adequado, como exibir uma mensagem para o usuário
        });
}

let poltronaSelecionada = null;

function selecionarPoltrona(element, numero) {
    if (element.classList.contains('ocupado')) return;

    if (poltronaSelecionada) {
        poltronaSelecionada.classList.remove('selecionado');
    }
    poltronaSelecionada = element;
    element.classList.add('selecionado');
}

function escolherPoltrona() {
    if (!poltronaSelecionada) {
        alert('Por favor, selecione uma poltrona.');
        return;
    }

    const salaId = document.getElementById('sala').value;
    const numero = poltronaSelecionada.innerText;

    // Exibe um alerta solicitando confirmação da escolha da poltrona
    if (!confirm(`Deseja selecionar a poltrona ${numero} na sala ${salaId}?`)) {
        return; // Se o usuário cancelar, a função termina aqui
    }

    // Aqui você pode enviar a poltrona selecionada para o servidor, por exemplo, usando fetch() ou AJAX
    // Exemplo simplificado:
    fetch('/selecionar_poltrona', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ sala_id: salaId, poltrona_numero: numero })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Se a seleção for bem-sucedida, exibe um alerta e atualiza a aparência da poltrona selecionada
            alert('Poltrona selecionada com sucesso!');
            poltronaSelecionada.classList.remove('selecionado');
            poltronaSelecionada.classList.add('ocupado');
            poltronaSelecionada = null;
        } else {
            // Se houver algum erro, exibe uma mensagem de erro ou padrão
            alert(data.message || 'Erro ao selecionar poltrona.');
        }
    })
    .catch(error => {
        // Em caso de erro na requisição, exibe uma mensagem de erro genérica
        alert('Erro ao conectar-se ao servidor.');
        console.error('Erro:', error);
    });
}
