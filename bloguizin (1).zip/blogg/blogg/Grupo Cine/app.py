from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Lista de frutas (exemplo)


@app.route('/')
def index():
    return render_template('index.html')

# Rota para renderizar about.html
@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        # Processar os dados do formulário de contato
        nome = request.form.get('nome')
        telefone = request.form.get('fone')
        email = request.form.get('email')
        opiniao = request.form.get('opiniao')
        
        # Aqui você pode adicionar lógica para salvar os dados ou enviá-los por e-mail
        
        # Redireciona para uma página de agradecimento ou recarrega a página com uma mensagem
        return redirect(url_for('contact_success', nome=nome))
    
    return render_template('contact.html')

# Rota para exibir uma mensagem de sucesso após o envio do formulário de contato
@app.route('/contact/success')
def contact_success():
    nome = request.args.get('nome', '')
    return render_template('contact_success.html', nome=nome)


# usuarios permitidos
usuarios = {
    'usuario1': {'username': 'usuario1', 'password': 'senha1'},
    'usuario2': {'username': 'usuario2', 'password': 'senha2'}
}

# Rota para renderizar a página de login e processar o formulário
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        # Verificar se o usuário existe e a senha está correta
        if username in usuarios and usuarios[username]['password'] == password:
            # Se o login for bem-sucedido, redirecionar para página de sucesso
            return redirect(url_for('login_success', username=username))
        else:
            # Se o login falhar, renderizar a página de login novamente com uma mensagem de erro
            error_message = "Credenciais inválidas. Por favor, tente novamente."
            return render_template('login.html', error_message=error_message)
    
    # Se o método for GET, renderizar a página de login
    return render_template('login.html')

# Rota para exibir página de sucesso após o login
@app.route('/login-success/<username>')
def login_success(username):
    return render_template('loginSuccess.html', username=username)

@app.route('/produtos')
def produtos():
    return render_template('produtos.html')

@app.route('/feedback', methods=['GET', 'POST'])
def feedback():
    feedback_enviado = False

    if request.method == 'POST':
        nome = request.form.get('nomesobrenome')
        email = request.form.get('email')
        telefone = request.form.get('telefone')
        
        # Aqui você pode adicionar o processamento dos dados do formulário.

        feedback_enviado = True

    return render_template('feedback.html', feedback_enviado=feedback_enviado)

if __name__ == "__main__":
    app.run(debug=True)
